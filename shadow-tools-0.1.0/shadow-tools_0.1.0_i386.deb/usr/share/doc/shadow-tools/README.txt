===========
Shadow Tools
===========

A simple app for changing and restoring passwords in /etc/shadow
